#include "../include/Simulation.h"

int main()
{
    Simulation simulation;
    simulation.run();

    return 0;
}