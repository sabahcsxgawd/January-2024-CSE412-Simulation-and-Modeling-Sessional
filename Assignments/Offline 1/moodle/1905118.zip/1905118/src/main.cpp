#include "../include/Simulation.h"

int main()
{
    Simulation sim;
    sim.run();

    return 0;
}

