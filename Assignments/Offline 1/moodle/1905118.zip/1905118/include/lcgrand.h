/* Define the constants. */

#define MODLUS 2147483647
#define MULT1 24112
#define MULT2 26143

double lcgrand(int stream);