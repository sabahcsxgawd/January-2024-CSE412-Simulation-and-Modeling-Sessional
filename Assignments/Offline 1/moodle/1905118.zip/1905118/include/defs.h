#define IDLE 0
#define BUSY 1
#define INF 1.0e+30